// importing "useState" hook from react library
import { useState } from "react";

// importing "Dropdown".css file
import "./Dropdown.css";

// Defining a functional component named "Dropdown"
function Dropdown() {
    // Defining state variables to manage the dropdown state
    const items = ["Yes", "Probably not"]; // Array of dropdown items - items array to display the items in the list.
    const [isOpen, setIsOpen] = useState(false); // State variable to track whether the dropdown is open or closed.
    const [selectedItem, setSelectedItem] = useState(null); // State variable to track the selected dropdown item.

    // Function to handle mouse enter event
    const handleMouseEnter = () => {
        setIsOpen(true); // Set isOpen state to true when mouse enters the dropdown
    };

    // Function to handle mouse leave event
    const handleMouseLeave = () => {
        setIsOpen(false); // Set isOpen state to false when mouse leaves the dropdown
    };

    // Function to handle selection of a dropdown item
    const handleSelect = (item) => {
        setSelectedItem(item); // Set selectedItem state to the selected item
        setIsOpen(false); // Close the dropdown
    };

    // Render the Dropdown component
    return (
        <div className="outer-div">
            {/* Heading */}
            <h1>Should you use a dropdown?</h1>
            {/* Dropdown container */}
            <div className="dropdown-container" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>

                {/* Dropdown button */}
                <button className="dropdown-btn">
                    {selectedItem || "Select"} {/* Display selected item or "Select" if no item is selected */}
                </button>

                {/* Dropdown list */}
                <div className="inner-div">
                    {isOpen && items.map((item, key) => (
                        // Render each dropdown item
                        <div className="dropdown-list" key={key} onClick={() => handleSelect(item)}>
                            {item} {/* Display dropdown item */}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

// Exporting the Dropdown component
export default Dropdown;
