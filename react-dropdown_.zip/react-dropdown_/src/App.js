import Dropdown from './Component/Dropdown/Dropdown.js';

function App() {
  return (
    <div>
      <Dropdown/>
    </div>
  );
}

export default App;
